import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template:'',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Welcome to Movie world';
}