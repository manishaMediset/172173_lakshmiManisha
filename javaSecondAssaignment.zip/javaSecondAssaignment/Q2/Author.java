package assaignment.Q2;

public class Author {
	static String name;
	static String email;
	static char gender;
	public Author(String name, String email, char gender) {
		super();
		this.name = name;
		this.email = email;
		this.gender = gender;
	}
	public String getName() {
		return name;
	}
	public String getEmail() {
		return email;
	}
	public char getGender() {
		/*if(char=="m"|| char=="f"||char=="F"||char="M") {
		
		}*/
		
			
		return gender;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	@Override
	public String toString() {
		return "Author [name=" + name + ", email=" + email + ", gender=" + gender + "]";
	}
	
	

}
