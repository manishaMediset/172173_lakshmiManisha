package assaignment.Q2;
import assaignment.Q2.*;


public class Composition {

	public static void main(String[] args)
	{
		Author a=new Author("manisha","manisha@gmail.com",'F');
		Book b=new Book("java");
		b.setPrice(300);
		b.setQty(10);
		System.out.println(b);
	}
}