package assaignment.Q3;

public class Account2 {

	public static void main(String[] args) {
		Customer1 c=new Customer1(1,"manisha",20);
		System.out.println(c);
		Account a=new Account();
		a.setBalance(800000);
		a.credit(200000.3789);
		System.out.println(a);
		a.withdraw(80000);
		System.out.println(a);
	}

}
