package assaignment.Q4;

public class Person1
{
	String name;
	String Address;
	
	public Person1(String name, String address) 
	{
		//super();
		this.name = name;
		Address = address;
	}

	
	public void setAddress()
	{
		this.Address=Address;
	}
	
	public String getName()
	{
		return name;
	}

	public String getAddress() 
	{
		return Address;
	}
 
	public String toString()
	{
		return  "From ToString method     NAME:"+name+"  "+"ADDRESS:"+Address;
	}
	
}
