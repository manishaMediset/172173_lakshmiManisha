package com.assaignment.q1;
@FunctionalInterface
public interface Arthematic {
 int calculate(int x,int y);
}
