package com.assaignment.q1;

import java.util.Scanner;

public class Test1 {
   public static void main(String [] args) {
	
	   
	   Arthematic add = (int x, int y)-> x+y;
	   Arthematic sub= (int x, int y)-> x-y;
	   Arthematic mul = (int x, int y)-> x*y;
	   Arthematic div = (int x, int y)-> x/y;
      Scanner sc = new Scanner(System.in);
      System.out.println("enter two numbers::");
      int a = sc.nextInt();
      int b = sc.nextInt();
      int addition = add.calculate(a, b);
       System.out.println("addition::"+addition);  
       int substraction = sub.calculate(a, b);
       System.out.println("substration::"+substraction); 
       int multiplication = mul.calculate(a, b);
       System.out.println("multiplication::"+multiplication); 
       int division = div.calculate(a, b);
       System.out.println("division::"+division); 
   }
}
