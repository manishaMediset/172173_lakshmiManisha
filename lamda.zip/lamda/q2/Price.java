package com.assaignment.q2;
@FunctionalInterface
public interface Price {
	void details(int amount);

}
