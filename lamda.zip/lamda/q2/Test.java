package com.assaignment.q2;

import java.util.Scanner;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Price p = (amount)->
		{
			if(amount>10000)
				System.out.println("accepted");
			else
				System.out.println("Completed");
		};
		 Scanner sc = new Scanner(System.in);
	      System.out.println("enter amount::");
	      int amt = sc.nextInt();
	      p.details(amt);

	}

}
