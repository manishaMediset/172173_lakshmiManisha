package com.assaignment.q4;

import java.util.ArrayList;
import java.util.List;

public class RemoveOddElement {
  
	public static void main(String []args) {
		List<String> list = new ArrayList<String>();
		list.add("manisha");
		list.add("mani");
		list.add("nisha");
		list.add("isha");
		list.add("manu");
		list.add("anisha");
		System.out.println("names::"+list);
		System.out.println("_______________________________");
		list.removeIf(arr -> arr.length()%2==1);
		list.forEach(System.out::println);
		

	}


}
