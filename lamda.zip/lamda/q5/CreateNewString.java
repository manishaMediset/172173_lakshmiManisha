package com.assaignment.q5;

import java.util.ArrayList;
import java.util.List;

public class CreateNewString {
	//private static final String entrySet = null;
	public static void main(String []args) {
		List<String> list = new ArrayList<String>();
		list.add("manisha");
		list.add("anisha");
		list.add("nisha");
		list.add("isha");
		list.add("sha");
		list.add("ha");
		list.add("a");
		System.out.println("names::"+list);
		System.out.println("_______________________________");
		String name = list.stream().map(nam -> Character.toString(nam.charAt(0))).reduce( " ",(a , b) -> a+b);
		System.out.println(name);

}
}
