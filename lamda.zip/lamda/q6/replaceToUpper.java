package com.assaignment.q6;

import java.util.ArrayList;
import java.util.List;

public class replaceToUpper {

	public static void main(String []args) {
		List<String> list = new ArrayList<String>();
		list.add("manisha");
		list.add("mani");
		list.add("nisha");
		list.add("isha");
		list.add("manu");
		list.add("anisha");
		System.out.println("names::"+list);
		System.out.println("_______________________________");
		list.replaceAll(arr -> arr.toUpperCase());
		list.forEach(System.out::println);
		
}
}
