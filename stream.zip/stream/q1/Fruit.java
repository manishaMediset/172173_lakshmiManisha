//class Fruit { String name; int calories; int price; String color; }
package com.stream.q1;

public class Fruit {
	String name;
	int caloroies;
	int price;
	String color;
	public Fruit(String name, int caloroies, int price, String color) {
		super();
		this.name = name;
		this.caloroies = caloroies;
		this.price = price;
		this.color = color;
	}
	public String getName() {
		return name;
	}
	public int getCaloroies() {
		return caloroies;
	}
	public int getPrice() {
		return price;
	}
	public String getColor() {
		return color;
	}
	

}
