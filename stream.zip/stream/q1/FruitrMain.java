/*
 1. Display the fruit names of low calories fruits i.e. calories < 100 sorted in descending order of calories.
2. Display color wise list of fruit names.
3. Display only RED color fruits sorted as per their price in ascending order.
 */
package com.stream.q1;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class FruitrMain {
	public static void main(String [] args) {
		List<Fruit> list = new ArrayList<>();
		list.add(new Fruit("blueberry",450,500,"blue"));
		list.add(new Fruit("apple",90,100,"red"));
		list.add(new Fruit("strawberry",110,150,"red"));
		list.add(new Fruit("banana",60,50,"yellow"));
		list.add(new Fruit("grapes",200,100,"green"));
		list.add(new Fruit("orange",150,75,"orange"));
		list.add(new Fruit("guava",70,140,"green"));
		list.add(new Fruit("mosambi",55,120,"green"));
		List<String> list2 = list.stream()
				.filter(p->p.getCaloroies()<100)
				.sorted(Comparator.comparing(Fruit::getCaloroies).reversed())
				.map(Fruit::getName)
				.collect(Collectors.toList());
		
	list2.forEach(System.out::println);
	System.out.println("-------------------------------------");
	List<Fruit> list3=list.stream()
			.sorted(Comparator.comparing(Fruit::getColor))
			.collect(Collectors.toList());
	list3.forEach(e->System.out.println("Fruit is "+e.getName()+" Colour is "+e.getColor()));
	System.out.println("------------------------------------");
	List<String> list4=list.stream()
			.filter(p->p.getColor()=="red")
			.sorted(Comparator.comparing(Fruit::getPrice))
			.map(Fruit::getName)
			.collect(Collectors.toList());
	list4.forEach(System.out::println);
	//System.out.println("----------------------------------");
	

	}
	

	}

		
	


