/*
 4. Find out the newsId which has received maximum comments.
5. Find out how many times the word 'budget' arrived in user comments all news.
6. Find out which user has posted maximum comments.
7. Display commentByUser wise number of comments.
 */

package com.stream.q1;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class NewsTest {
	public static void main(String [] args) {
		List<News> list = new ArrayList<>();
		list.add(new News(555,"abc", "Anushka shetty married virat kohli",  "yes it is"));
		list.add(new News(556, "bcd","AP elections going to be conduted in may","no"));
		list.add(new News(557,"cde", "Budget was planned for the special status",  "yes"));
		list.add(new News(558,"def", "IT sector playing a lead role", "yes"));
		list.add(new News(559,"efg", "42 soliders was died in the attack",  "true"));
		list.add(new News(560,"jkl", "Swatch bharat is introduced", "yes"));
		list.add(new News(555, "abc","Anushka shetty married virat kohli", "true"));
		List<News> list2 = list.stream()
				.filter(p->p.getCommentByUser().contains("Anushka")).collect(Collectors.toList());
		list2.forEach(p->System.out.println(p.getCommentByUser()));

		//List list3=list.stream().count();
		//System.out.println("Anushka shetty married virat kohli"+l);
		//System.out.println("-------------------------------------------");
		//List<News> list3=list.stream().filter(p->p.getNewsId().).collect(Collectors.toList());
				

	}

}
