/*
 9. What are all the unique cities where the traders work?
10. Find all traders from Pune and sort them by name.
11. Return a string of all traders� names sorted alphabetically.
12. Are any traders based in Indore?
 */
package com.stream.q1;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class TradeMain {

	public static void main(String[] args) {
		List<Trader> list=new ArrayList<>();
		list.add(new Trader("manisha", "Banglore"));
		list.add(new Trader("sahithi","Hyderabad"));
		list.add(new Trader("deepthi", "Indore"));
		list.add(new Trader("rani", "Pune"));
		list.add(new Trader("kanisha", "mumbai"));
		list.add(new Trader("supriya", "Bangalore"));
		list.add(new Trader("paddu", "Pune"));
		list.add(new Trader("niyamsh", "Hyderabad"));
		list.add(new Trader("krutwik", "Pune"));
		list.add(new Trader("aaruhi", "Banglore"));
		
		
		System.out.println("Assignment 9 --------------------");
		System.out.println("Unique Cities are>>>>>");
		List<String> names3=list.stream()
				.map(Trader::getCity)
				.distinct()
				.collect(Collectors.toList());
		names3.forEach(System.out::println);
		
		
		System.out.println("Assignment 10 --------------------");
		List<Trader> names=list.stream()
				.filter(p->p.getCity()=="Pune")
				.sorted(Comparator.comparing(Trader::getName))
				.collect(Collectors.toList());
		names.forEach(s->System.out.println(s.getName()));
		
		System.out.println("Assignment 11 --------------------");
		System.out.println("Traders names are>>>>>");
		List<Trader> names4=list.stream()
				.sorted(Comparator.comparing(Trader::getName))
				.collect(Collectors.toList());
		String S=names4.stream()
				.map(Trader::getName)
				.collect(Collectors.joining(", "));
		System.out.println(S);
		
		
		System.out.println("Assignment 12 --------------------");
		System.out.println("Traders based in Indore are_>>>>>");
		List<String> names2=list.stream()
				.filter(p->p.getCity()=="Indore")
				.map(Trader::getName)
				.collect(Collectors.toList());
		names2.forEach(System.out::println);
		
		
		
		
	}

}
