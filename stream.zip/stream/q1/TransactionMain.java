/*
 13. Print all transactions� values from the traders living in Delhi.
14. What�s the highest value of all the transactions?
15. Find the transaction with the smallest value.
 */



package com.stream.q1;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;


public class TransactionMain {





	public static void main(String[] args) {
		List<Transaction>list = new ArrayList<>();
		list.add(new Transaction(new Trader("manisha","Punjab"),2011,3500));
		list.add(new Transaction(new Trader("nisha","Mumbai"),2012,3000));
		list.add(new Transaction(new Trader("isha","Delhi"),2017,2000));
		list.add(new Transaction(new Trader("kohi","Pune"),2011,4500));
		list.add(new Transaction(new Trader("minnu","Kolkata"),2011,1500));
		
		System.out.println("Assignment queston 8--------------------");
		List<Transaction> trans=list.stream()
				.filter(p->p.getYear()==2011)
				.sorted(Comparator.comparing(Transaction::getValue))
				.collect(Collectors.toList());
		trans.forEach(e->System.out.println("transaction value: "+e.getValue()+" in the year "+e.getYear()+" done by "+e.getTrader().getName()));
		
		System.out.println("Assignment queston 13--------------------");
		List<Transaction> trans2=list.stream()
				.filter(p->p.getTrader().getCity()=="Delhi")
				.collect(Collectors.toList());
		trans2.forEach(e->System.out.println("Transaction value is: "+e.getValue()+" done by "+e.getTrader().getName()));
		
		System.out.println("Assignment queston 14--------------------");
		Transaction max=list.stream()
				.max((p1,p2)->Integer.compare(p1.getValue(), p2.getValue()))
				.get();
		System.out.println(max.getValue());
		
		System.out.println("Assignment queston 15--------------------");
		Transaction max2=list.stream()
				.min((p1,p2)->Integer.compare(p1.getValue(), p2.getValue()))
				.get();
		System.out.println(max2.getValue());
		
		

	}
}
